A Pen created at CodePen.io. You can find this one at https://codepen.io/frederick-armando/pen/POyGvL.

 Simple concept of an Error 404 - Page not found page using shake animation